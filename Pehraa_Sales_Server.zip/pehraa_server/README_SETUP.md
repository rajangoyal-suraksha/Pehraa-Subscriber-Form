# Pehraa Sales Intake System — Setup & Deployment Guide

This is a self-hosted application: a Node.js server, a SQLite database (a
single file — no separate database server to install), and a set of web
pages. It runs entirely on your own T560 server; nothing here depends on
Google, and nothing leaves your network except the two things you choose to
enable (outbound email, and later, Razorpay).

---

## 1. Install prerequisites on the T560

1. **Install Node.js (LTS, version 18 or newer)** — download the Windows
   installer from nodejs.org and run it. This also installs `npm`
   (Node's package manager), which you'll use once.
2. Confirm it installed: open **Command Prompt** and run:
   ```
   node --version
   npm --version
   ```
   Both should print a version number.

## 2. Copy the project onto the server

Copy the whole `pehraa-server` folder (everything in this delivery) onto
the T560 — e.g. `C:\Pehraa\pehraa-server`.

## 3. Install the application's dependencies

Open Command Prompt, navigate into the folder, and run:
```
cd C:\Pehraa\pehraa-server
npm install
```
This downloads the handful of libraries the app uses (Express, the
database driver, etc.) — it needs internet access this one time; after
that, the app runs fully offline except for email/Razorpay calls.

## 4. Configure your settings

1. Copy `.env.example` to a new file named exactly `.env` in the same
   folder.
2. Open `.env` in Notepad and fill in real values:
   - **SESSION_SECRET** and **ENCRYPTION_KEY** — generate each with:
     ```
     node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
     ```
     Run it twice (once per value) and paste each result in. **Treat
     ENCRYPTION_KEY like a password that protects every Aadhaar number and
     bank account number stored in the system — if it's ever lost, that
     data becomes permanently unreadable; if it ever leaks, that data
     becomes readable by whoever has it. Back it up somewhere separate
     from the server itself (a password manager, not a text file next to
     the database).**
   - **SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / SMTP_FROM** — your
     email sending account. For Gmail: host `smtp.gmail.com`, port `587`,
     your address, and an **App Password** (Google Account → Security →
     2-Step Verification → App Passwords — NOT your normal Gmail
     password, Google blocks normal-password SMTP login).
   - **APP_BASE_URL** — the address your team/customers will actually use
     to reach this server (see Section 6 on HTTPS/networking below). For
     now, if you're just testing on the same machine, leave it as
     `http://localhost:3000`.
   - Leave **RAZORPAY_ENABLED=false** until your Razorpay account is
     ready (see Section 8).

## 5. Create the first admin account

```
npm run seed
```
This asks for a name, email, Agent ID, and password on the command line,
and creates the one account you need to log in and start adding other
users from the Admin panel. You only run this once, ever — further users
are created from inside the app.

## 6. Start the server

```
npm start
```
You should see: `Pehraa server running at ...`. Leave this window open —
closing it stops the server (Section 7 covers running it permanently in
the background).

Open a browser to `http://localhost:3000` (or the server's IP address
from another computer on the same network, e.g. `http://192.168.1.50:3000`)
and log in with the admin account you just created.

### Making it reachable from outside your office network

If your sales team needs to reach this from outside (not just on the
office Wi-Fi), that needs one of:
- A **VPN** into your office network (most secure, recommended if your
  team already has one, or your IT provider can set one up)
- **Port forwarding** on your router/firewall to the T560, plus a real
  domain name and an HTTPS certificate (see below) — more exposed to the
  internet, needs more careful firewall configuration
- A reverse proxy / tunnelling service (e.g. Cloudflare Tunnel) — a
  middle-ground option that avoids opening inbound firewall ports directly

This decision has real security implications given the data involved
(Aadhaar numbers, bank details) — if you don't already have an IT
person/provider for this part, it's worth bringing one in specifically
for the network exposure decision, even if everything else here you
handle yourselves.

## 7. Keep it running permanently (as a Windows Service)

Running `npm start` in a Command Prompt window stops the moment that
window closes or the server reboots. To keep it running permanently:

**Recommended: NSSM (Non-Sucking Service Manager)** — a free, widely-used
tool for exactly this:
1. Download NSSM from nssm.cc, extract it.
2. Open Command Prompt **as Administrator**, navigate to where you
   extracted it, and run:
   ```
   nssm install PehraaServer
   ```
3. In the dialog: **Path** = the full path to `node.exe` (find it with
   `where node`), **Startup directory** = your `pehraa-server` folder,
   **Arguments** = `server.js`.
4. Click **Install service**. Then start it:
   ```
   nssm start PehraaServer
   ```
It will now start automatically with Windows and restart if it crashes.

## 8. HTTPS (strongly recommended before real customer data goes through)

Running over plain HTTP means data (including Aadhaar numbers typed by
your sales reps) travels unencrypted on the network. Two realistic paths:

- **If you have a domain name** pointing at this server: use
  [win-acme](https://www.win-acme.com/) to get a free, auto-renewing
  HTTPS certificate from Let's Encrypt, and set up IIS or a tool like
  Caddy as a reverse proxy in front of the Node app (the Node app itself
  listens on plain HTTP; the proxy handles HTTPS and forwards to it).
- **If this stays internal-only** (VPN or office network only): a
  self-signed certificate is enough to encrypt the traffic, though
  browsers will show a one-time warning to trust it.

This part — like the networking decision above — is worth a short
conversation with an IT person if you don't have HTTPS set up elsewhere
already; getting it wrong doesn't fail loudly, it just silently leaves
data exposed.

## 9. Before real customer data goes through this system

A short checklist, given this handles Aadhaar numbers and bank details:
- [ ] `.env` is configured with real, unique `SESSION_SECRET` and
      `ENCRYPTION_KEY` values (not left as the example placeholders)
- [ ] HTTPS is set up (Section 8) if reachable outside a trusted network
- [ ] Windows Firewall only allows the port this app uses (3000 by
      default) from where it actually needs to be reached from
- [ ] You have a backup plan for the `data/` folder (the database file
      and every uploaded document/signature live there) — copy it
      somewhere else on a regular schedule, the same way you'd back up
      any folder of important files
- [ ] You've done at least one full end-to-end test yourself: log in,
      submit a test application, open the emailed link, upload a test
      document, sign, confirm the thank-you email arrives with both PDFs
      attached, check the Customers list and Excel export show the
      record correctly
- [ ] Ideally, someone with security experience has looked over the
      setup once — I've built this carefully, but "carefully built by one
      reviewer" and "reviewed for production use with real identity
      documents" are different bars, and the second one matters given
      what this stores

## 10. Day-to-day use

- **Sales reps**: log in at your server's address, "New Application" is
  the main form. Plans dropdown, auto-fill, and validation all work as
  specified. On submit, the applicant gets emailed their own
  Documents & Signature link automatically.
- **Admins**: the "Admin" tab manages Plans (add/edit/deactivate — a
  deactivated plan drops off the dropdown for new applications but
  existing customers who used it are unaffected) and Users (create
  accounts, assign roles, deactivate).
- **Everyone**: the "Customers" tab lists all applications and has an
  **Export to Excel** button for the master customer sheet — what each
  role sees there is already scoped (viewers get masked account numbers,
  for instance).

## 11. Enabling Razorpay once your account is ready

1. Get your **Key ID** and **Key Secret** from the Razorpay dashboard.
2. In `.env`, set `RAZORPAY_ENABLED=true` and paste in both values.
3. Restart the server (`nssm restart PehraaServer`, or re-run `npm start`
   if running manually).

The order-creation and payment-verification endpoints
(`src/paymentRazorpay.js`) are already built against Razorpay's
documented REST API and signature-verification scheme — this flips them
from "not configured" to live. The one piece still to add at that point
is the Razorpay Checkout button itself on the applicant's payment step in
`intake_public.html` (currently there's no payment step in the applicant
flow yet — tell me when you're ready and I'll wire that part in too,
including deciding where in the flow payment should sit — before or
after document upload).

---

## What this build does not include yet (by design, per our last discussion)

- **Aadhaar OTP verification** — needs a licensed eKYC provider
  relationship first (see earlier discussion)
- **Bank account → name lookup ("penny drop")** — needs a paid
  verification API provider chosen and signed up
- **WhatsApp delivery of the intake link** — needs Meta Business
  verification and an approved message template

All three have a clear slot to be wired in once you've made those
business decisions — none of them require restructuring what's already
built.
