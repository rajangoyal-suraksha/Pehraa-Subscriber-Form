// Shared across every page under /app — confirms the viewer is logged in
// and renders a consistent top bar. Each page just needs:
//   <div id="topbar"></div>  <script src="common.js"></script>
// then call PehraaCommon.init({ active: 'intake' }) once the DOM is ready.

const PehraaCommon = (function () {
  let currentUser = null;

  async function fetchMe() {
    const res = await fetch('/api/me');
    if (!res.ok) { window.location.href = '/login.html'; return null; }
    const data = await res.json();
    currentUser = data.user;
    return currentUser;
  }

  function renderTopbar(active) {
    const el = document.getElementById('topbar');
    if (!el || !currentUser) return;
    const links = [
      { href: '/app/index.html', key: 'intake', label: 'New Application', roles: ['admin', 'sales'] },
      { href: '/app/customers.html', key: 'customers', label: 'Customers', roles: ['admin', 'sales', 'viewer'] },
      { href: '/app/admin.html', key: 'admin', label: 'Admin', roles: ['admin'] },
    ].filter((l) => l.roles.includes(currentUser.role));

    el.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;
                  background:#1a1a1a;color:#fff;padding:10px 18px;font-family:Arial,Helvetica,sans-serif;">
        <div style="display:flex;align-items:center;gap:18px;">
          <strong style="color:#FFBC5E;">PEHRAA</strong>
          ${links.map((l) => `<a href="${l.href}" style="color:${l.key === active ? '#FFBC5E' : '#fff'};
            text-decoration:none;font-size:13px;font-weight:${l.key === active ? 'bold' : 'normal'};">${l.label}</a>`).join('')}
        </div>
        <div style="font-size:12px;display:flex;align-items:center;gap:12px;">
          <span>${currentUser.name} (${currentUser.agentId}) — ${currentUser.role}</span>
          <button id="logoutBtn" style="background:none;border:1px solid #666;color:#fff;border-radius:4px;
            padding:5px 10px;cursor:pointer;font-size:12px;">Sign out</button>
        </div>
      </div>`;
    document.getElementById('logoutBtn').addEventListener('click', async () => {
      await fetch('/api/logout', { method: 'POST' });
      window.location.href = '/login.html';
    });
  }

  async function init(opts) {
    const user = await fetchMe();
    if (!user) return null;
    renderTopbar(opts && opts.active);
    return user;
  }

  return { init, getUser: () => currentUser };
})();
