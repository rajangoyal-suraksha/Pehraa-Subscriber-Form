require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');

const { router: authRouter, requireLogin, requireRole } = require('./src/auth');
const plansRouter = require('./src/plans');
const usersRouter = require('./src/users');
const ifscRouter = require('./src/ifsc');
const { router: customersRouter } = require('./src/customers');
const intakePublicRouter = require('./src/intakePublic');
const exportRouter = require('./src/exportExcel');
const paymentRouter = require('./src/paymentRazorpay');

const app = express();

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.APP_BASE_URL && process.env.APP_BASE_URL.startsWith('https'),
    maxAge: 12 * 60 * 60 * 1000, // 12 hours
  },
}));

// A few basic security headers by hand (no extra dependency needed for this).
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

// ---- Public routes (no login) ----
app.use(authRouter); // /api/login, /api/logout, /api/me
app.use(intakePublicRouter); // /intake/:token and its APIs
app.use(ifscRouter); // /api/ifsc/:code — read-only public data lookup, safe unauthenticated
app.use(paymentRouter); // /api/payment/* — order creation is scoped to a customer code, verification uses Razorpay's own signature check
app.use('/terms', express.static(path.join(__dirname, 'assets'))); // public T&C PDF link shown on the intake form

// ---- Everything else requires login ----
app.use('/app', requireLogin, express.static(path.join(__dirname, 'public', 'app')));
app.use(requireLogin, plansRouter);
app.use(requireLogin, usersRouter);
app.use(requireLogin, customersRouter);
app.use(requireLogin, exportRouter);

// Static files: login page is public, everything under /app requires login
// (enforced above), served separately so the login page itself is reachable
// before authenticating.
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

app.get('/', (req, res) => {
  res.redirect(req.session.user ? '/app/index.html' : '/login.html');
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server. Check the server logs for details.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Pehraa server running at ${process.env.APP_BASE_URL || 'http://localhost:' + PORT}`);
});
