// Generates a letterhead-branded PDF snapshot of a customer's full
// application — same visual pattern as the Pehraa letterhead supplied
// (logo + contact top, company name/address/GST/CIN bottom).
const fs = require('fs');
const path = require('path');
const { PDFDocument, StandardFonts, rgb } = require('pdf-lib');

const PAGE_W = 595.28, PAGE_H = 841.89; // A4
const MARGIN = 42;
const CONTENT_W = PAGE_W - MARGIN * 2;
const DARK = rgb(0.08, 0.08, 0.08);
const GRAY = rgb(0.33, 0.33, 0.33);
const MID_GRAY = rgb(0.45, 0.45, 0.45);
const BLUE = rgb(22 / 255, 74 / 255, 148 / 255);
const LIGHT_GRAY = rgb(0.85, 0.85, 0.85);

const LETTERHEAD = {
  website: 'pehraa.com',
  email: 'info@pehraa.com',
  phones: '90574 00051  /  90576 00051',
  companyName: 'Suraksha24 Technologies Pvt. Ltd.',
  address: '2nd Floor, Noble Enclave, Bhai Wala Chowk, Opp. Hotel Park Plaza, Ludhiana, Punjab, India - 141001',
  gst: '03ABSCS5496C1Z0',
  // NOTE: the official letterhead shows "LU80200PB2026PTC067016" (leading
  // "LU"); this project's earlier records use "U80200PB2026PTC067016"
  // (no "L"). Flagged previously as unresolved — confirm which is correct
  // and fix here if needed.
  cin: 'LU80200PB2026PTC067016',
};

function wrapText(font, size, text, maxWidth) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let current = '';
  for (const w of words) {
    const test = current ? current + ' ' + w : w;
    if (font.widthOfTextAtSize(test, size) > maxWidth && current) {
      lines.push(current);
      current = w;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines;
}

/**
 * @param {string} customerCode e.g. "PHR-000001"
 * @param {Array<{label: string, value: string}>} fields flat list of label/value pairs to print
 * @param {string} outPath where to write the PDF
 */
async function generateApplicationPdf(customerCode, fields, outPath) {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.setTitle('Pehraa Subscriber Application — ' + customerCode);

  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const logoBytes = fs.readFileSync(path.join(__dirname, '..', 'assets', 'logo_blue.png'));
  const logoImg = await pdfDoc.embedPng(logoBytes);
  const logoDims = { width: logoImg.width, height: logoImg.height };

  const S = { page: null, y: 0, pageIndex: 0 };

  function drawText(text, x, y, opts = {}) {
    const { size = 9.5, f = font, color = DARK } = opts;
    S.page.drawText(String(text), { x, y, size, font: f, color });
  }
  function drawTextRight(text, xRight, y, opts = {}) {
    const { size = 9.5, f = font, color = DARK } = opts;
    const w = f.widthOfTextAtSize(String(text), size);
    S.page.drawText(String(text), { x: xRight - w, y, size, font: f, color });
  }
  function hline(x1, x2, y, opts = {}) {
    const { color = LIGHT_GRAY, thickness = 0.7 } = opts;
    S.page.drawLine({ start: { x: x1, y }, end: { x: x2, y }, thickness, color });
  }

  function header() {
    const topY = PAGE_H - 32;
    const w = 95;
    const h = w * (logoDims.height / logoDims.width);
    S.page.drawImage(logoImg, { x: MARGIN, y: topY - h + 4, width: w, height: h });
    drawTextRight(LETTERHEAD.website, PAGE_W - MARGIN, topY - 1, { size: 9, color: BLUE });
    drawTextRight(LETTERHEAD.email, PAGE_W - MARGIN, topY - 11, { size: 9, color: BLUE });
    drawTextRight(LETTERHEAD.phones, PAGE_W - MARGIN, topY - 21, { size: 9, color: BLUE });
    hline(MARGIN, PAGE_W - MARGIN, topY - h - 3, { color: DARK, thickness: 1.2 });
    return topY - h - 15;
  }

  function footer() {
    const fy = 46;
    hline(MARGIN, PAGE_W - MARGIN, fy + 24, { color: LIGHT_GRAY, thickness: 0.8 });
    drawText(LETTERHEAD.companyName, MARGIN, fy + 14, { f: fontBold, size: 9, color: BLUE });
    const addrLines = wrapText(font, 7.5, LETTERHEAD.address, CONTENT_W * 0.6);
    let ay = fy + 4;
    for (const l of addrLines) { drawText(l, MARGIN, ay, { size: 7.5, color: MID_GRAY }); ay -= 9; }
    drawTextRight('GST: ' + LETTERHEAD.gst, PAGE_W - MARGIN, fy + 14, { size: 7.5, color: MID_GRAY });
    drawTextRight('CIN: ' + LETTERHEAD.cin, PAGE_W - MARGIN, fy + 4, { size: 7.5, color: MID_GRAY });
    drawTextRight('Page ' + S.pageIndex, PAGE_W - MARGIN, 24, { size: 7, color: MID_GRAY });
  }

  function newPage() {
    if (S.page) footer();
    S.page = pdfDoc.addPage([PAGE_W, PAGE_H]);
    S.pageIndex++;
    S.y = header();
    return S.page;
  }
  function ensureSpace(h) {
    if (S.y - h < 90) newPage();
  }

  newPage();
  drawText('Subscriber Application Summary', MARGIN, S.y, { f: fontBold, size: 14 });
  S.y -= 18;
  drawText('Customer ID: ' + customerCode, MARGIN, S.y, { size: 10 });
  S.y -= 13;
  drawText('Generated: ' + new Date().toLocaleString('en-IN'), MARGIN, S.y, { size: 9, color: MID_GRAY });
  S.y -= 20;

  for (const { label, value } of fields) {
    if (value === undefined || value === null || value === '') continue;
    ensureSpace(28);
    drawText(label, MARGIN, S.y, { f: fontBold, size: 8.8, color: BLUE });
    S.y -= 11;
    const lines = wrapText(font, 9.3, String(value), CONTENT_W);
    for (const l of lines) { ensureSpace(12); drawText(l, MARGIN, S.y, { size: 9.3 }); S.y -= 12; }
    S.y -= 5;
  }

  footer();

  const bytes = await pdfDoc.save();
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, bytes);
  return outPath;
}

module.exports = { generateApplicationPdf, LETTERHEAD };
