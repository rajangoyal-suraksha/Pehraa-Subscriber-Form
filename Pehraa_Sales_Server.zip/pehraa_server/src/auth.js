const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('./db');

const router = express.Router();

// ---- Login / logout ----
router.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

  const user = db.prepare('SELECT * FROM users WHERE email = ? AND active = 1').get(String(email).trim().toLowerCase());
  if (!user) return res.status(401).json({ error: 'Invalid email or password.' });

  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid email or password.' });

  req.session.user = { id: user.id, agentId: user.agent_id, name: user.name, email: user.email, role: user.role };
  res.json({ ok: true, user: req.session.user });
});

router.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get('/api/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in.' });
  res.json({ user: req.session.user });
});

// ---- Middleware ----
function requireLogin(req, res, next) {
  if (!req.session || !req.session.user) {
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Not logged in.' });
    return res.redirect('/login.html');
  }
  next();
}

// requireRole(['admin']) or requireRole(['admin','sales']) etc.
function requireRole(roles) {
  return function (req, res, next) {
    if (!req.session || !req.session.user) {
      if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Not logged in.' });
      return res.redirect('/login.html');
    }
    if (!roles.includes(req.session.user.role)) {
      return res.status(403).json({ error: 'You do not have permission to do that.' });
    }
    next();
  };
}

module.exports = { router, requireLogin, requireRole };
