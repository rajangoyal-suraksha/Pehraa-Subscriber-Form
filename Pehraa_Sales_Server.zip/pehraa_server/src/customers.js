const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const { requireRole } = require('./auth');
const { validateCustomerPayload } = require('./validate');
const { encrypt, decrypt } = require('./crypto');
const { generateApplicationPdf } = require('./applicationPdf');
const { sendIntakeLinkEmail } = require('./mailer');

const router = express.Router();
const DATA_DIR = path.join(__dirname, '..', 'data', 'customers');

function nextCustomerCode() {
  const row = db.prepare("SELECT value FROM counters WHERE name = 'customer_seq'").get();
  const next = row.value + 1;
  db.prepare("UPDATE counters SET value = ? WHERE name = 'customer_seq'").run(next);
  return 'PHR-' + String(next).padStart(6, '0');
}

function buildApplicationFields(c, plan) {
  const L = (label, value) => ({ label, value });
  return [
    L('Sales Executive / Agent ID', c._agentId),
    L('Applicant Type', c.applicant_type),
    L('First Name', c.first_name), L('Surname', c.surname),
    L('Business / Organisation Name', c.business_name), L('GSTIN / PAN', c.gstin_pan),
    L('Type of Property', c.property_type === 'Other' ? c.property_type_other : c.property_type),
    L('Billing Address', [c.billing_address, c.billing_city, c.billing_state, c.billing_pin].filter(Boolean).join(', ')),
    L('Site / Installation Address', c.site_same_as_billing
      ? 'Same as billing address'
      : [c.site_address, c.site_city, c.site_state, c.site_pin].filter(Boolean).join(', ')),
    L('Mobile Number', c.mobile_number), L('Alternate / WhatsApp Number', c.alt_number),
    L('Email Address', c.email), L('Landmark', c.landmark),
    L('1st Emergency Contact', [c.ec1_name, c.ec1_relation, c.ec1_number].filter(Boolean).join(' / ')),
    L('2nd Emergency Contact', [c.ec2_name, c.ec2_relation, c.ec2_number].filter(Boolean).join(' / ')),
    L('3rd Emergency Contact', [c.ec3_name, c.ec3_relation, c.ec3_number].filter(Boolean).join(' / ')),
    L('4th Emergency Contact', [c.ec4_name, c.ec4_relation, c.ec4_number].filter(Boolean).join(' / ')),
    L('5th / Other Local Emergency Contact', [c.ec5_name, c.ec5_relation, c.ec5_number].filter(Boolean).join(' / ')),
    L('Nearest Police Station', [c.police_station, c.police_number].filter(Boolean).join(' / ')),
    L('Nearest Hospital', c.hospital),
    L('SOP — Authorised Actions', c.sop_actions),
    L('SOP — Other Instruction', c.sop_other), L('SOP — Priority Notes', c.sop_notes),
    L('Plan Selected', plan ? plan.name : c.plan_name_snapshot),
    L('Monthly Subscription Fee (Rs.)', c.monthly_fee_snapshot), L('One-Time Installation Charges (Rs.)', c.installation_fee),
    L('Billing Cycle', c.billing_cycle),
    L('Minimum Commitment Acknowledged', c.commitment_ack ? 'Yes' : 'No'),
    L('Pre-Authorisation Payment Mode', c.payment_mode),
    L('Bank Name', c.bank_name), L('Account Holder Name', c.account_holder_name),
    L('Account Number', c.account_number), L('IFSC Code', c.ifsc_code), L('UPI ID', c.upi_id),
    L('Pre-Authorisation Consent', c.preauth_consent ? 'Yes' : 'No'),
    L('Aadhaar Number', c.aadhaar_last4 ? ('XXXXXXXX' + c.aadhaar_last4) : ''),
    L('Address Proof Type', c.address_proof_type),
    L('Terms & Conditions Agreed', c.tnc_agree ? 'Yes' : 'No'),
    L('KYC Declaration Agreed', c.kyc_agree ? 'Yes' : 'No'),
    L('Declared Name (Applicant/Authorised Signatory)', c.declare_name),
  ];
}

// ---- Create a new customer application (sales rep, logged in) ----
router.post('/api/customers', requireRole(['admin', 'sales']), async (req, res) => {
  const b = req.body || {};
  const errors = validateCustomerPayload(b);
  if (errors.length) return res.status(400).json({ errors });

  const plan = db.prepare('SELECT * FROM plans WHERE id = ? AND active = 1').get(b.plan_id);
  if (!plan) return res.status(400).json({ errors: ['Selected plan was not found or is no longer active.'] });

  const customerCode = nextCustomerCode();
  const intakeToken = crypto.randomBytes(24).toString('hex');
  const aadhaarDigits = String(b.aadhaar_number).trim();

  const insert = db.prepare(`
    INSERT INTO customers (
      customer_code, created_by_user_id,
      applicant_type, first_name, surname, business_name, gstin_pan, property_type, property_type_other,
      billing_address, billing_city, billing_state, billing_pin,
      site_same_as_billing, site_address, site_city, site_state, site_pin,
      mobile_number, alt_number, email, landmark,
      ec1_name, ec1_relation, ec1_number, ec2_name, ec2_relation, ec2_number,
      ec3_name, ec3_relation, ec3_number, ec4_name, ec4_relation, ec4_number,
      ec5_name, ec5_relation, ec5_number,
      police_station, police_number, hospital, sop_actions, sop_other, sop_notes,
      plan_id, plan_name_snapshot, monthly_fee_snapshot, installation_fee, billing_cycle, commitment_ack,
      payment_mode, bank_name, account_holder_name, account_number, ifsc_code, upi_id, card_last4, preauth_consent,
      aadhaar_encrypted, aadhaar_last4, address_proof_type,
      tnc_agree, kyc_agree, declare_name, intake_token
    ) VALUES (
      @customer_code, @created_by_user_id,
      @applicant_type, @first_name, @surname, @business_name, @gstin_pan, @property_type, @property_type_other,
      @billing_address, @billing_city, @billing_state, @billing_pin,
      @site_same_as_billing, @site_address, @site_city, @site_state, @site_pin,
      @mobile_number, @alt_number, @email, @landmark,
      @ec1_name, @ec1_relation, @ec1_number, @ec2_name, @ec2_relation, @ec2_number,
      @ec3_name, @ec3_relation, @ec3_number, @ec4_name, @ec4_relation, @ec4_number,
      @ec5_name, @ec5_relation, @ec5_number,
      @police_station, @police_number, @hospital, @sop_actions, @sop_other, @sop_notes,
      @plan_id, @plan_name_snapshot, @monthly_fee_snapshot, @installation_fee, @billing_cycle, @commitment_ack,
      @payment_mode, @bank_name, @account_holder_name, @account_number, @ifsc_code, @upi_id, @card_last4, @preauth_consent,
      @aadhaar_encrypted, @aadhaar_last4, @address_proof_type,
      @tnc_agree, @kyc_agree, @declare_name, @intake_token
    )
  `);

  const info = insert.run({
    customer_code: customerCode,
    created_by_user_id: req.session.user.id,
    applicant_type: b.applicant_type || null,
    first_name: b.first_name, surname: b.surname,
    business_name: b.business_name || null, gstin_pan: b.gstin_pan || null,
    property_type: b.property_type || null, property_type_other: b.property_type_other || null,
    billing_address: b.billing_address, billing_city: b.billing_city, billing_state: b.billing_state, billing_pin: b.billing_pin,
    site_same_as_billing: b.site_same_as_billing ? 1 : 0,
    site_address: b.site_same_as_billing ? b.billing_address : (b.site_address || null),
    site_city: b.site_same_as_billing ? b.billing_city : (b.site_city || null),
    site_state: b.site_same_as_billing ? b.billing_state : (b.site_state || null),
    site_pin: b.site_same_as_billing ? b.billing_pin : (b.site_pin || null),
    mobile_number: b.mobile_number, alt_number: b.alt_number || null, email: b.email, landmark: b.landmark || null,
    ec1_name: b.ec1_name || null, ec1_relation: b.ec1_relation || null, ec1_number: b.ec1_number || null,
    ec2_name: b.ec2_name || null, ec2_relation: b.ec2_relation || null, ec2_number: b.ec2_number || null,
    ec3_name: b.ec3_name || null, ec3_relation: b.ec3_relation || null, ec3_number: b.ec3_number || null,
    ec4_name: b.ec4_name || null, ec4_relation: b.ec4_relation || null, ec4_number: b.ec4_number || null,
    ec5_name: b.ec5_name || null, ec5_relation: b.ec5_relation || null, ec5_number: b.ec5_number || null,
    police_station: b.police_station || null, police_number: b.police_number || null, hospital: b.hospital || null,
    sop_actions: Array.isArray(b.sop_actions) ? b.sop_actions.join(', ') : (b.sop_actions || null),
    sop_other: b.sop_other || null, sop_notes: b.sop_notes || null,
    plan_id: plan.id, plan_name_snapshot: plan.name, monthly_fee_snapshot: plan.monthly_fee,
    installation_fee: b.installation_fee !== undefined ? Number(b.installation_fee) : plan.installation_fee,
    billing_cycle: b.billing_cycle, commitment_ack: b.commitment_ack ? 1 : 0,
    payment_mode: b.payment_mode,
    bank_name: b.bank_name || null, account_holder_name: b.account_holder_name || null,
    account_number: b.account_number || null, ifsc_code: b.ifsc_code || null,
    upi_id: b.upi_id || null, card_last4: b.card_last4 || null,
    preauth_consent: b.preauth_consent ? 1 : 0,
    aadhaar_encrypted: encrypt(aadhaarDigits), aadhaar_last4: aadhaarDigits.slice(-4),
    address_proof_type: b.address_proof_type,
    tnc_agree: b.tnc_agree ? 1 : 0, kyc_agree: b.kyc_agree ? 1 : 0, declare_name: b.declare_name || null,
    intake_token: intakeToken,
  });

  // Create the customer's own folder on disk — everything for this
  // applicant (documents, signature, generated PDFs) lives here.
  const customerDir = path.join(DATA_DIR, customerCode);
  fs.mkdirSync(customerDir, { recursive: true });

  // Generate the branded application PDF now (used both for the rep's
  // records and re-attached to the applicant's thank-you email later).
  const pdfPath = path.join(customerDir, customerCode + '_Application.pdf');
  try {
    const fields = buildApplicationFields(
      Object.assign({}, b, { _agentId: req.session.user.agentId, aadhaar_last4: aadhaarDigits.slice(-4) }),
      plan
    );
    await generateApplicationPdf(customerCode, fields, pdfPath);
    db.prepare('UPDATE customers SET application_pdf_path = ? WHERE id = ?').run(pdfPath, info.lastInsertRowid);
  } catch (err) {
    console.error('Could not generate application PDF for', customerCode, err);
  }

  const intakeUrl = `${process.env.APP_BASE_URL}/intake/${intakeToken}`;
  try {
    await sendIntakeLinkEmail(b.email, b.first_name, customerCode, intakeUrl);
  } catch (err) {
    console.error('Could not email applicant for', customerCode, err);
    return res.json({
      ok: true, customerCode,
      warning: 'Customer saved, but the Documents & Signature email could not be sent automatically. ' +
        'Share this link with the applicant yourself: ' + intakeUrl,
    });
  }

  res.json({ ok: true, customerCode });
});

// ---- List customers (role-aware: viewers get a redacted Aadhaar column) ----
router.get('/api/customers', requireRole(['admin', 'sales', 'viewer']), (req, res) => {
  const rows = db.prepare(`
    SELECT c.*, u.name AS created_by_name, u.agent_id AS created_by_agent_id
    FROM customers c LEFT JOIN users u ON u.id = c.created_by_user_id
    ORDER BY c.created_at DESC
  `).all();
  const safe = rows.map((r) => ({
    ...r,
    aadhaar_encrypted: undefined,
    aadhaar_masked: r.aadhaar_last4 ? 'XXXXXXXX' + r.aadhaar_last4 : null,
    account_number: req.session.user.role === 'admin' ? r.account_number : maskAccountNumber(r.account_number),
  }));
  res.json({ customers: safe });
});

function maskAccountNumber(num) {
  if (!num) return num;
  const s = String(num);
  return s.length <= 4 ? s : 'X'.repeat(s.length - 4) + s.slice(-4);
}

module.exports = { router, buildApplicationFields };
