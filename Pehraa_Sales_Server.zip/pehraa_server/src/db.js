// SQLite database — a single file on disk (./data/pehraa.db). No separate
// database server to install or secure; the file itself is what you back up.
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'pehraa.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT UNIQUE NOT NULL,       -- short code shown on the intake form, e.g. "RAJ01"
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','sales','viewer')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  monthly_fee REAL NOT NULL,
  installation_fee REAL NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS counters (
  name TEXT PRIMARY KEY,
  value INTEGER NOT NULL
);
INSERT OR IGNORE INTO counters (name, value) VALUES ('customer_seq', 0);

CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_code TEXT UNIQUE NOT NULL,   -- e.g. PHR-000001 (this doubles as the account number)
  created_by_user_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending_documents', -- pending_documents | documents_received | active

  -- Section A
  applicant_type TEXT, first_name TEXT, surname TEXT,
  business_name TEXT, gstin_pan TEXT, property_type TEXT, property_type_other TEXT,
  billing_address TEXT, billing_city TEXT, billing_state TEXT, billing_pin TEXT,
  site_same_as_billing INTEGER,
  site_address TEXT, site_city TEXT, site_state TEXT, site_pin TEXT,
  mobile_number TEXT, alt_number TEXT, email TEXT, landmark TEXT,

  -- Section B
  ec1_name TEXT, ec1_relation TEXT, ec1_number TEXT,
  ec2_name TEXT, ec2_relation TEXT, ec2_number TEXT,
  ec3_name TEXT, ec3_relation TEXT, ec3_number TEXT,
  ec4_name TEXT, ec4_relation TEXT, ec4_number TEXT,
  ec5_name TEXT, ec5_relation TEXT, ec5_number TEXT,
  police_station TEXT, police_number TEXT, hospital TEXT,
  sop_actions TEXT, sop_other TEXT, sop_notes TEXT,

  -- Section C
  plan_id INTEGER REFERENCES plans(id),
  plan_name_snapshot TEXT, monthly_fee_snapshot REAL, installation_fee REAL,
  billing_cycle TEXT, commitment_ack INTEGER,
  payment_mode TEXT,
  bank_name TEXT, account_holder_name TEXT, account_number TEXT, ifsc_code TEXT,
  upi_id TEXT, card_last4 TEXT,
  preauth_consent INTEGER,

  -- Section D (Aadhaar number is stored ENCRYPTED; aadhaar_last4 kept in the
  -- clear only for display purposes so staff never need to decrypt just to
  -- recognise a record)
  aadhaar_encrypted TEXT, aadhaar_last4 TEXT,
  address_proof_type TEXT,

  -- Section E/F
  tnc_agree INTEGER, kyc_agree INTEGER, declare_name TEXT,

  -- Documents & signature (public intake step)
  intake_token TEXT UNIQUE,
  tnc_accepted_at TEXT,
  signature_path TEXT,
  application_pdf_path TEXT,

  -- Payment (Razorpay — populated once enabled)
  payment_status TEXT NOT NULL DEFAULT 'not_configured', -- not_configured | pending | paid | failed
  razorpay_order_id TEXT, razorpay_payment_id TEXT,

  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS customer_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  doc_type TEXT NOT NULL,  -- aadhaar | address_proof | photo | business_proof
  filename TEXT NOT NULL,
  path TEXT NOT NULL,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

module.exports = db;
