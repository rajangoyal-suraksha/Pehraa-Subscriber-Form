const express = require('express');
const ExcelJS = require('exceljs');
const db = require('./db');
const { requireRole } = require('./auth');

const router = express.Router();

router.get('/api/export/customers.xlsx', requireRole(['admin', 'sales', 'viewer']), async (req, res) => {
  const isAdmin = req.session.user.role === 'admin';
  const rows = db.prepare(`
    SELECT c.*, u.name AS created_by_name, u.agent_id AS created_by_agent_id
    FROM customers c LEFT JOIN users u ON u.id = c.created_by_user_id
    ORDER BY c.created_at DESC
  `).all();

  const wb = new ExcelJS.Workbook();
  wb.creator = 'Pehraa Sales Intake System';
  const sheet = wb.addWorksheet('Customers');

  const columns = [
    { header: 'Customer ID', key: 'customer_code', width: 14 },
    { header: 'Status', key: 'status', width: 16 },
    { header: 'Created', key: 'created_at', width: 18 },
    { header: 'Agent', key: 'created_by_name', width: 16 },
    { header: 'Agent ID', key: 'created_by_agent_id', width: 10 },
    { header: 'First Name', key: 'first_name', width: 14 },
    { header: 'Surname', key: 'surname', width: 14 },
    { header: 'Business Name', key: 'business_name', width: 18 },
    { header: 'Mobile', key: 'mobile_number', width: 12 },
    { header: 'Email', key: 'email', width: 22 },
    { header: 'Billing Address', key: 'billing_address', width: 28 },
    { header: 'City', key: 'billing_city', width: 14 },
    { header: 'State', key: 'billing_state', width: 14 },
    { header: 'PIN', key: 'billing_pin', width: 10 },
    { header: 'Plan', key: 'plan_name_snapshot', width: 16 },
    { header: 'Monthly Fee', key: 'monthly_fee_snapshot', width: 12 },
    { header: 'Installation Fee', key: 'installation_fee', width: 14 },
    { header: 'Billing Cycle', key: 'billing_cycle', width: 12 },
    { header: 'Payment Mode', key: 'payment_mode', width: 20 },
    { header: 'Aadhaar (masked)', key: 'aadhaar_masked', width: 16 },
    { header: 'Address Proof Type', key: 'address_proof_type', width: 16 },
    { header: 'T&C Accepted At', key: 'tnc_accepted_at', width: 18 },
    { header: 'Payment Status', key: 'payment_status', width: 14 },
  ];
  if (isAdmin) {
    columns.push(
      { header: 'Account Number', key: 'account_number', width: 16 },
      { header: 'IFSC', key: 'ifsc_code', width: 12 },
      { header: 'Bank Name', key: 'bank_name', width: 16 }
    );
  }
  sheet.columns = columns;
  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFBC5E' } };

  rows.forEach((r) => {
    sheet.addRow({
      ...r,
      aadhaar_masked: r.aadhaar_last4 ? 'XXXXXXXX' + r.aadhaar_last4 : '',
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="Pehraa_Customers.xlsx"');
  await wb.xlsx.write(res);
  res.end();
});

module.exports = router;
