// Proxies to Razorpay's free, public, no-signup-required IFSC lookup API
// (https://ifsc.razorpay.com/<CODE>) so the browser doesn't need to call a
// third-party domain directly (keeps it simple and avoids CORS issues).
// This is unrelated to Razorpay *payments* — it's just the IFSC directory
// they publish openly; it works whether or not you have a Razorpay account.
const express = require('express');
const router = express.Router();

router.get('/api/ifsc/:code', async (req, res) => {
  const code = String(req.params.code || '').trim().toUpperCase();
  if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(code)) {
    return res.status(400).json({ error: 'That doesn\'t look like a valid IFSC code (expected format: ABCD0123456).' });
  }
  try {
    const response = await fetch('https://ifsc.razorpay.com/' + code);
    if (response.status === 404) return res.status(404).json({ error: 'IFSC code not found.' });
    if (!response.ok) return res.status(502).json({ error: 'Lookup service returned an error.' });
    const data = await response.json();
    res.json({
      bank: data.BANK,
      branch: data.BRANCH,
      address: data.ADDRESS,
      city: data.CITY,
      state: data.STATE,
    });
  } catch (err) {
    res.status(502).json({ error: 'Could not reach the IFSC lookup service. Check the server\'s internet connection.' });
  }
});

module.exports = router;
