const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const { sendThankYouEmail } = require('./mailer');

const router = express.Router();
const DATA_DIR = path.join(__dirname, '..', 'data', 'customers');

function getCustomerByToken(token) {
  return db.prepare('SELECT * FROM customers WHERE intake_token = ?').get(token);
}

// Serves the public intake page itself (static HTML; the page's JS calls
// the APIs below using the token embedded in the URL).
router.get('/intake/:token', (req, res) => {
  const customer = getCustomerByToken(req.params.token);
  if (!customer) return res.status(404).send('This link is invalid or has expired. Please contact Pehraa Customer Support.');
  res.sendFile(path.join(__dirname, '..', 'public', 'intake_public.html'));
});

// Basic info the public page needs to render (never includes anything
// sensitive — no Aadhaar, no bank details).
router.get('/api/intake/:token/info', (req, res) => {
  const customer = getCustomerByToken(req.params.token);
  if (!customer) return res.status(404).json({ error: 'Invalid or expired link.' });
  res.json({
    customerCode: customer.customer_code,
    firstName: customer.first_name,
    status: customer.status,
  });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const customer = getCustomerByToken(req.params.token);
    if (!customer) return cb(new Error('Invalid token'));
    const dir = path.join(DATA_DIR, customer.customer_code);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const customer = getCustomerByToken(req.params.token);
    const safeField = file.fieldname.replace(/[^a-zA-Z0-9_]/g, '');
    const ext = path.extname(file.originalname) || '';
    cb(null, `${customer.customer_code}_${safeField}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB per file
  fileFilter: (req, file, cb) => {
    const ok = /^image\/|^application\/pdf$/.test(file.mimetype);
    cb(ok ? null : new Error('Only images and PDF files are allowed.'), ok);
  },
});

const uploadFields = upload.fields([
  { name: 'aadhaar', maxCount: 1 },
  { name: 'addressProof', maxCount: 1 },
  { name: 'photo', maxCount: 1 },
  { name: 'businessProof', maxCount: 1 },
  { name: 'signature', maxCount: 1 },
]);

router.post('/api/intake/:token/submit', (req, res) => {
  uploadFields(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });

    const customer = getCustomerByToken(req.params.token);
    if (!customer) return res.status(404).json({ error: 'Invalid or expired link.' });

    const tncAccepted = req.body.tncAccepted === 'true' || req.body.tncAccepted === true;
    if (!tncAccepted) return res.status(400).json({ error: 'Terms & Conditions must be accepted before submitting.' });

    const files = req.files || {};
    if (!files.signature) return res.status(400).json({ error: 'A signature is required.' });

    const customerDir = path.join(DATA_DIR, customer.customer_code);

    Object.keys(files).forEach((fieldName) => {
      const f = files[fieldName][0];
      db.prepare(
        'INSERT INTO customer_documents (customer_id, doc_type, filename, path) VALUES (?, ?, ?, ?)'
      ).run(customer.id, fieldName, f.filename, f.path);
    });

    const tncAcceptedAt = new Date().toISOString();
    fs.writeFileSync(
      path.join(customerDir, customer.customer_code + '_TnC_Acceptance.txt'),
      `Pehraa — Terms & Conditions Acceptance Record\n` +
      `Customer ID: ${customer.customer_code}\n` +
      `Accepted at: ${tncAcceptedAt}\n`
    );

    db.prepare(
      `UPDATE customers SET status = 'documents_received', tnc_accepted_at = ?, signature_path = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(tncAcceptedAt, files.signature[0].path, customer.id);

    // Thank-you email with the application PDF + T&C PDF attached, if both
    // are available. Best-effort: a failed email never blocks the
    // already-saved documents/signature from being considered a success.
    try {
      const attachments = [];
      if (customer.application_pdf_path && fs.existsSync(customer.application_pdf_path)) {
        attachments.push(customer.application_pdf_path);
      }
      const tncPdfPath = path.join(__dirname, '..', 'assets', 'Pehraa_Terms_and_Conditions.pdf');
      if (fs.existsSync(tncPdfPath)) attachments.push(tncPdfPath);

      if (attachments.length) {
        await sendThankYouEmail(customer.email, customer.first_name, customer.customer_code, attachments);
      }
    } catch (err) {
      console.error('Could not send thank-you email for', customer.customer_code, err);
    }

    res.json({ ok: true });
  });
});

module.exports = router;
