const nodemailer = require('nodemailer');

function getTransport() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
}

async function sendMail({ to, subject, text, html, attachments }) {
  const transport = getTransport();
  return transport.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to, subject, text, html, attachments,
  });
}

// Sent right after the sales rep submits the Section A-F form — gives the
// applicant their own link to open on their phone for documents + signature.
async function sendIntakeLinkEmail(applicantEmail, firstName, customerCode, intakeUrl) {
  const text =
    `Dear ${firstName},\n\n` +
    `Thank you for applying for Pehraa 24x7 alarm monitoring. Your reference Customer ID is: ${customerCode}\n\n` +
    `To complete your application, please open the link below on your phone. You will be asked to read and accept ` +
    `our Terms & Conditions, then attach your Aadhaar card, address proof, a photo, and (if applicable) business ` +
    `documents, and sign on-screen:\n\n${intakeUrl}\n\n` +
    `If the link above does not open directly, copy and paste the entire address into your phone's browser.\n\n` +
    `Regards,\nTeam Pehraa`;
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#1a1a1a;line-height:1.5;">` +
    `<p>Dear ${firstName},</p>` +
    `<p>Thank you for applying for Pehraa 24x7 alarm monitoring. Your reference Customer ID is: <b>${customerCode}</b></p>` +
    `<p>To complete your application, please open the button below on your phone. You will be asked to read and ` +
    `accept our Terms &amp; Conditions, then attach your Aadhaar card, address proof, a photo, and (if applicable) ` +
    `business documents, and sign on-screen.</p>` +
    `<p><a href="${intakeUrl}" style="display:inline-block;background:#FFBC5E;color:#1a1a1a;font-weight:bold;` +
    `padding:12px 22px;border-radius:6px;text-decoration:none;">Attach Documents &amp; Sign</a></p>` +
    `<p style="font-size:12px;color:#777;">If the button above does not work, copy and paste this full address ` +
    `into your phone's browser:<br>${intakeUrl}</p>` +
    `<p>Regards,<br>Team Pehraa</p></div>`;
  return sendMail({ to: applicantEmail, subject: 'Pehraa — Action needed: documents & signature', text, html });
}

// Sent once the applicant finishes documents + signature — the final
// thank-you with their application PDF and the T&C PDF attached.
async function sendThankYouEmail(applicantEmail, firstName, customerCode, attachmentPaths) {
  const text =
    `Dear ${firstName},\n\n` +
    `Thank you — your Pehraa 24x7 alarm monitoring application is now complete. Your Customer ID is: ${customerCode}\n\n` +
    `We have received your documents and signature. Attached to this email, for your records, is a copy of your ` +
    `completed application and our Terms & Conditions.\n\nRegards,\nTeam Pehraa`;
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#1a1a1a;line-height:1.5;">` +
    `<p>Dear ${firstName},</p>` +
    `<p>Thank you — your Pehraa 24x7 alarm monitoring application is now complete. Your Customer ID is: <b>${customerCode}</b></p>` +
    `<p>We have received your documents and signature. Attached to this email, for your records, is a copy of ` +
    `your completed application and our Terms &amp; Conditions.</p>` +
    `<p>Regards,<br>Team Pehraa</p></div>`;
  return sendMail({
    to: applicantEmail,
    subject: `Pehraa — Thank you! Your application is complete (${customerCode})`,
    text, html,
    attachments: attachmentPaths.map((p) => ({ path: p })),
  });
}

module.exports = { sendMail, sendIntakeLinkEmail, sendThankYouEmail };
