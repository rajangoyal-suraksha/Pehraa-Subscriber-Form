// Razorpay integration point. While RAZORPAY_ENABLED is not "true" in .env,
// every route here responds clearly that payments aren't configured yet,
// rather than failing confusingly. Once you have a Razorpay account:
//   1. Set RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET / RAZORPAY_ENABLED=true in .env
//   2. Add the Razorpay Checkout script tag to intake_public.html (commented
//      stub already left in place there) — nothing else needs to change.
const express = require('express');
const crypto = require('crypto');
const db = require('./db');

const router = express.Router();

function isEnabled() {
  return String(process.env.RAZORPAY_ENABLED).toLowerCase() === 'true' &&
    process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET;
}

router.get('/api/payment/status', (req, res) => {
  res.json({ enabled: isEnabled() });
});

// Creates a Razorpay Order for the first subscription payment. Uses
// Razorpay's plain REST API directly (no SDK dependency needed) via the
// standard Basic-Auth key_id:key_secret scheme they document.
router.post('/api/payment/create-order/:customerCode', async (req, res) => {
  if (!isEnabled()) {
    return res.status(503).json({
      error: 'Online payment is not configured yet. This will be enabled once the Razorpay account is set up ' +
        '(set RAZORPAY_ENABLED=true and the two key variables in .env).',
    });
  }
  const customer = db.prepare('SELECT * FROM customers WHERE customer_code = ?').get(req.params.customerCode);
  if (!customer) return res.status(404).json({ error: 'Customer not found.' });

  const amountPaise = Math.round(Number(customer.monthly_fee_snapshot + (customer.installation_fee || 0)) * 100);
  const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');

  try {
    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: amountPaise,
        currency: 'INR',
        receipt: customer.customer_code,
        notes: { customer_code: customer.customer_code },
      }),
    });
    const order = await response.json();
    if (!response.ok) return res.status(502).json({ error: order.error ? order.error.description : 'Razorpay order creation failed.' });

    db.prepare("UPDATE customers SET razorpay_order_id = ?, payment_status = 'pending' WHERE id = ?")
      .run(order.id, customer.id);

    res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (err) {
    res.status(502).json({ error: 'Could not reach Razorpay: ' + err.message });
  }
});

// Verifies the payment signature Razorpay's Checkout returns to the
// browser after a successful payment — standard HMAC-SHA256 scheme per
// Razorpay's documented verification procedure.
router.post('/api/payment/verify', (req, res) => {
  if (!isEnabled()) return res.status(503).json({ error: 'Online payment is not configured yet.' });

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ error: 'Missing payment verification fields.' });
  }

  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(razorpay_order_id + '|' + razorpay_payment_id)
    .digest('hex');

  if (expected !== razorpay_signature) {
    return res.status(400).json({ error: 'Payment signature could not be verified.' });
  }

  db.prepare("UPDATE customers SET payment_status = 'paid', razorpay_payment_id = ? WHERE razorpay_order_id = ?")
    .run(razorpay_payment_id, razorpay_order_id);

  res.json({ ok: true });
});

module.exports = router;
