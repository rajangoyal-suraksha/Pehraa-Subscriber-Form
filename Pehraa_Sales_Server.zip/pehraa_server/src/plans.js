const express = require('express');
const db = require('./db');
const { requireRole } = require('./auth');

const router = express.Router();

// Any logged-in role can READ the plan list (needed to populate the
// dropdown on the intake form); only admins can add/edit/delete.
router.get('/api/plans', (req, res) => {
  const includeInactive = req.query.all === '1' && req.session.user && req.session.user.role === 'admin';
  const rows = includeInactive
    ? db.prepare('SELECT * FROM plans ORDER BY name').all()
    : db.prepare('SELECT * FROM plans WHERE active = 1 ORDER BY name').all();
  res.json({ plans: rows });
});

router.post('/api/plans', requireRole(['admin']), (req, res) => {
  const { name, monthly_fee, installation_fee } = req.body || {};
  if (!name || monthly_fee === undefined || installation_fee === undefined) {
    return res.status(400).json({ error: 'name, monthly_fee and installation_fee are required.' });
  }
  if (isNaN(Number(monthly_fee)) || isNaN(Number(installation_fee))) {
    return res.status(400).json({ error: 'Fees must be numbers.' });
  }
  try {
    const info = db.prepare(
      'INSERT INTO plans (name, monthly_fee, installation_fee) VALUES (?, ?, ?)'
    ).run(String(name).trim(), Number(monthly_fee), Number(installation_fee));
    res.json({ ok: true, id: info.lastInsertRowid });
  } catch (err) {
    if (String(err).includes('UNIQUE')) return res.status(409).json({ error: 'A plan with that name already exists.' });
    res.status(500).json({ error: 'Could not create plan.' });
  }
});

router.put('/api/plans/:id', requireRole(['admin']), (req, res) => {
  const { name, monthly_fee, installation_fee, active } = req.body || {};
  const existing = db.prepare('SELECT * FROM plans WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Plan not found.' });

  db.prepare(
    `UPDATE plans SET
      name = COALESCE(?, name),
      monthly_fee = COALESCE(?, monthly_fee),
      installation_fee = COALESCE(?, installation_fee),
      active = COALESCE(?, active),
      updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    name !== undefined ? String(name).trim() : null,
    monthly_fee !== undefined ? Number(monthly_fee) : null,
    installation_fee !== undefined ? Number(installation_fee) : null,
    active !== undefined ? (active ? 1 : 0) : null,
    req.params.id
  );
  res.json({ ok: true });
});

// Plans already used by a customer are never hard-deleted (that would
// corrupt historical records) — deleting just deactivates it so it drops
// off the dropdown for new applications.
router.delete('/api/plans/:id', requireRole(['admin']), (req, res) => {
  db.prepare("UPDATE plans SET active = 0, updated_at = datetime('now') WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
