// Run once, from the project folder: npm run seed
// Prompts for the first admin account's details on the command line.
// Further users (any role) are created from the Admin panel once logged in
// — this script only exists to bootstrap the very first login, since you
// can't create a user from the admin panel without already being logged in
// as an admin.
require('dotenv').config();
const readline = require('readline');
const bcrypt = require('bcryptjs');
const db = require('./db');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function ask(q) { return new Promise((resolve) => rl.question(q, resolve)); }

(async () => {
  console.log('--- Pehraa — create the first admin account ---');
  const name = await ask('Full name: ');
  const email = (await ask('Email (used to log in): ')).trim().toLowerCase();
  const agentId = (await ask('Agent/Admin ID (short code, e.g. ADMIN1): ')).trim().toUpperCase();
  const password = await ask('Password (min 8 characters): ');
  rl.close();

  if (!name || !email || !agentId || !password || password.length < 8) {
    console.error('All fields are required and password must be at least 8 characters. Aborted — nothing was created.');
    process.exit(1);
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    console.error('A user with that email already exists. Aborted.');
    process.exit(1);
  }

  const hash = bcrypt.hashSync(password, 12);
  db.prepare(
    'INSERT INTO users (agent_id, name, email, password_hash, role, active) VALUES (?, ?, ?, ?, ?, 1)'
  ).run(agentId, name, email, hash, 'admin');

  console.log('Admin account created. You can now log in at /login.html with that email and password.');
})();
