const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { requireRole } = require('./auth');

const router = express.Router();
const ROLES = ['admin', 'sales', 'viewer'];

router.get('/api/users', requireRole(['admin']), (req, res) => {
  const rows = db.prepare('SELECT id, agent_id, name, email, role, active, created_at FROM users ORDER BY name').all();
  res.json({ users: rows });
});

router.post('/api/users', requireRole(['admin']), (req, res) => {
  const { agent_id, name, email, password, role } = req.body || {};
  if (!agent_id || !name || !email || !password || !role) {
    return res.status(400).json({ error: 'agent_id, name, email, password and role are all required.' });
  }
  if (!ROLES.includes(role)) return res.status(400).json({ error: 'role must be one of: ' + ROLES.join(', ') });
  if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  try {
    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare(
      'INSERT INTO users (agent_id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)'
    ).run(String(agent_id).trim().toUpperCase(), String(name).trim(), String(email).trim().toLowerCase(), hash, role);
    res.json({ ok: true, id: info.lastInsertRowid });
  } catch (err) {
    if (String(err).includes('UNIQUE')) return res.status(409).json({ error: 'That Agent ID or email is already in use.' });
    res.status(500).json({ error: 'Could not create user.' });
  }
});

router.put('/api/users/:id', requireRole(['admin']), (req, res) => {
  const { name, role, active, password } = req.body || {};
  const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'User not found.' });
  if (role && !ROLES.includes(role)) return res.status(400).json({ error: 'role must be one of: ' + ROLES.join(', ') });

  db.prepare(
    `UPDATE users SET
      name = COALESCE(?, name),
      role = COALESCE(?, role),
      active = COALESCE(?, active)
     WHERE id = ?`
  ).run(name || null, role || null, active !== undefined ? (active ? 1 : 0) : null, req.params.id);

  if (password) {
    if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(password, 12), req.params.id);
  }
  res.json({ ok: true });
});

// Users are deactivated, never deleted — their past submissions must still
// show a meaningful "created by" record.
router.delete('/api/users/:id', requireRole(['admin']), (req, res) => {
  if (req.session.user.id === Number(req.params.id)) {
    return res.status(400).json({ error: 'You cannot deactivate your own account while logged in as it.' });
  }
  db.prepare('UPDATE users SET active = 0 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
