// Client-side JS gives instant feedback, but every one of these is
// re-checked here before anything is saved — a request that bypasses the
// browser (or a browser with JS disabled) must never be able to store bad
// data.
const PHONE_RE = /^[6-9]\d{9}$/; // 10 digits, standard Indian mobile prefix 6-9
const AADHAAR_RE = /^\d{12}$/;
const PAYMENT_REQUIRED_FIELDS = {
  'NACH / Bank e-Mandate': ['bank_name', 'account_holder_name', 'account_number', 'ifsc_code'],
  'UPI Autopay': ['upi_id'],
  'Debit / Credit Card standing instruction': ['card_last4'],
  'Post-Dated Cheques (PDC)': ['bank_name', 'account_holder_name'],
};
const ADDRESS_PROOF_TYPES = [
  'Electricity Bill', 'Passport', 'Voter ID', 'Bank Statement', 'Rent Agreement', 'GST Certificate', 'Other',
];

function validateCustomerPayload(b) {
  const errors = [];
  const req = (field, label) => { if (!b[field] || !String(b[field]).trim()) errors.push(label + ' is required.'); };

  req('first_name', 'First Name');
  req('surname', 'Surname');
  req('billing_address', 'Billing Address');
  req('billing_city', 'Billing City/District');
  req('billing_state', 'Billing State');
  req('billing_pin', 'Billing PIN Code');
  req('email', 'Applicant Email Address');
  req('plan_id', 'Plan Selected');
  req('billing_cycle', 'Billing Cycle');
  req('payment_mode', 'Payment Mode');
  req('aadhaar_number', 'Aadhaar Number');
  req('address_proof_type', 'Address Proof Type');
  req('ec1_name', '1st Emergency Contact Name');
  req('ec1_number', '1st Emergency Contact Mobile Number');

  if (b.mobile_number && !PHONE_RE.test(String(b.mobile_number).trim())) {
    errors.push('Mobile Number must be exactly 10 digits, starting with 6-9.');
  } else {
    req('mobile_number', 'Mobile Number');
  }
  if (b.alt_number && !PHONE_RE.test(String(b.alt_number).trim())) {
    errors.push('Alternate/WhatsApp Number must be exactly 10 digits, starting with 6-9.');
  }
  ['ec1_number', 'ec2_number', 'ec3_number', 'ec4_number', 'ec5_number'].forEach((f, i) => {
    if (b[f] && !PHONE_RE.test(String(b[f]).trim())) {
      errors.push(`Contact ${i + 1} Mobile Number must be exactly 10 digits, starting with 6-9.`);
    }
  });

  if (b.aadhaar_number && !AADHAAR_RE.test(String(b.aadhaar_number).trim())) {
    errors.push('Aadhaar Number must be exactly 12 digits.');
  }

  if (b.address_proof_type && !ADDRESS_PROOF_TYPES.includes(b.address_proof_type)) {
    errors.push('Address Proof Type is not a recognised option.');
  }

  if (b.payment_mode && PAYMENT_REQUIRED_FIELDS[b.payment_mode]) {
    PAYMENT_REQUIRED_FIELDS[b.payment_mode].forEach((f) => {
      if (!b[f] || !String(b[f]).trim()) {
        errors.push(`"${f.replace(/_/g, ' ')}" is required for the selected payment mode (${b.payment_mode}).`);
      }
    });
  }

  if (b.site_same_as_billing === false || b.site_same_as_billing === 'false' || b.site_same_as_billing === '0') {
    req('site_address', 'Site Address');
  }

  return errors;
}

module.exports = { validateCustomerPayload, PHONE_RE, AADHAAR_RE, PAYMENT_REQUIRED_FIELDS, ADDRESS_PROOF_TYPES };
